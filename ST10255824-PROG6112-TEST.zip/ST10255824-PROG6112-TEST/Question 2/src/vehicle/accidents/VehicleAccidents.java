/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package vehicle.accidents;

/**
 *
 * @author lab_services_student
 */
import java.util.Scanner;

public class VehicleAccidents {
 public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Input vehicle type, city, and total number of accidents
        System.out.print("Enter the accident vehicle type: ");
        String vehicleType = scanner.nextLine();

        System.out.print("Enter the city for the vehicle accidents: ");
        String city = scanner.nextLine();

        System.out.print("Enter the total " + vehicleType + " accidents for " + city + ": ");
        int accidentTotal = scanner.nextInt();

        // Create an instance of RoadAccidentReport
        RoadAccidentReport report = new RoadAccidentReport(vehicleType, city, accidentTotal);

        // Print the accident report
        report.printAccidentReport();
    }
}
