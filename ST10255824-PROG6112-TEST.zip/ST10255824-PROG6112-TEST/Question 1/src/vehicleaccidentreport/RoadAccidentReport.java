package vehicleaccidentreport;

import java.util.Scanner;

public class RoadAccidentReport {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
       
        // Creating arrays to store the cities and accidents data
        String[] cities = {"Cape Town", "Johannesburg", "Port Elizabeth"};
        int[][] accidents = new int[3][2]; // 3 cities, 2 types of vehicles (Car and Motorbike)
       
        // Input accident information for each city
        for (int i = 0; i < cities.length; i++) {
            System.out.println("Enter the number of car accidents in " + cities[i] + ": ");
            accidents[i][0] = scanner.nextInt(); // Car accidents
           
            System.out.println("Enter the number of motorbike accidents in " + cities[i] + ": ");
            accidents[i][1] = scanner.nextInt(); // Motorbike accidents
        }

        // Display the accident report with the total for each city
        System.out.println("\nVEHICLE ACCIDENT REPORT");
        System.out.println("*****************************");
        System.out.printf("%-15s %-10s %-10s %-10s\n", "City", "Car", "Motorbike", "Total");
        for (int i = 0; i < cities.length; i++) {
            int totalAccidents = accidents[i][0] + accidents[i][1]; // Total accidents for the city
            System.out.printf("%-15s %-10d %-10d %-10d\n", cities[i], accidents[i][0], accidents[i][1], totalAccidents);
        }

        // Display the total accidents for each city separately
        System.out.println("\nTOTAL ACCIDENTS PER CITY");
        System.out.println("*****************************");
        for (int i = 0; i < cities.length; i++) {
            int totalAccidents = accidents[i][0] + accidents[i][1];
            System.out.println("Total accidents in " + cities[i] + ": " + totalAccidents);
        }

        // Calculate and display the city with the most accidents
        int maxAccidents = 0;
        String maxCity = "";
        for (int i = 0; i < cities.length; i++) {
            int totalAccidents = accidents[i][0] + accidents[i][1];
            if (totalAccidents > maxAccidents) {
                maxAccidents = totalAccidents;
                maxCity = cities[i];
            }
        }

        System.out.println("\nThe city with the greatest number of road accidents is: " + maxCity + " with " + maxAccidents + " total accidents.");
    }
}
